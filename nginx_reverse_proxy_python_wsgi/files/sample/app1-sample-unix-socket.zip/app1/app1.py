from routes import *

print(" *"*14, "Welcome to APP1", " *"*14)


if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=55001)


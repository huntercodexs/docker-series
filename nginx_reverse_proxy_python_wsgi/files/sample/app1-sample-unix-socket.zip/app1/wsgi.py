from app1 import *

if __name__ == "__main__":
    app.run()
